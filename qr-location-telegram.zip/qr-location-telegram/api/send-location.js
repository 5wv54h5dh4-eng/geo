module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ ok: false, error: 'Метод не поддерживается.' });
  }

  const token = process.env.BOT_TOKEN;
  const chatId = process.env.CHAT_ID;
  if (!token || !chatId) {
    return res.status(500).json({ ok: false, error: 'На сервере не настроены BOT_TOKEN и CHAT_ID.' });
  }

  const { latitude, longitude, accuracy } = req.body || {};
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude) ||
      latitude < -90 || latitude > 90 || longitude < -180 || longitude > 180) {
    return res.status(400).json({ ok: false, error: 'Получены некорректные координаты.' });
  }

  const payload = {
    chat_id: chatId,
    latitude,
    longitude
  };

  if (Number.isFinite(accuracy) && accuracy >= 0 && accuracy <= 1500) {
    payload.horizontal_accuracy = accuracy;
  }

  try {
    const telegramResponse = await fetch(`https://api.telegram.org/bot${token}/sendLocation`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const telegramResult = await telegramResponse.json();

    if (!telegramResponse.ok || !telegramResult.ok) {
      return res.status(502).json({ ok: false, error: 'Telegram не принял геолокацию. Проверьте настройки бота.' });
    }

    return res.status(200).json({ ok: true });
  } catch (error) {
    return res.status(500).json({ ok: false, error: 'Не удалось связаться с Telegram.' });
  }
};
